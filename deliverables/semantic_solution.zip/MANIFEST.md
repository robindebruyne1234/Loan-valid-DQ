# semantic_solution.zip -- what is in here and where to start

This archive is the "semantic solution and any code/agents" deliverable for the
Berka take-home. It is a snapshot of the repository minus the raw data files
(17 MB of public PKDD'99 data; README.md says where to get them), minus the
Excel workbook and the Design Decision Record (separate deliverables; the DDR's
source text is `deliverables/DDR_source.md`), and minus the walkthrough
preparation and the historical review records, which stay in the repository.

## Read in this order

1. `README.md` -- what was built, how to run it, and an index of the documents.
   `docs/DELIVERY_AUDIT.md` -- every important claim mapped to its evidence,
   the test results of this build, and the known limitations.
   `docs/GETTING_STARTED.md` (Linux, WSL, Docker) or
   `docs/LOCAL_LLM_WINDOWS.md` (native Windows with a local Ollama model) to
   run it yourself.
2. `docs/DEMO_SCRIPT.md` -- how to show the privacy model to stakeholders in
   fifteen minutes: what to run, what to point at, and the questions to
   expect. Driven by `make demo-login`; `make web` is the same story as a
   page you click through, and `docs/DEPLOYMENT.md` puts that page on a
   free-tier host behind TLS.
3. `docs/ACCESS_AND_AUTH.md` -- the design behind it: three kinds of
   identifier, four sources of access (ownership, disposition, portfolio,
   delegation) and two factors enforced by the database rather than by an
   application. Figures 11 and 12.
4. `docs/WORKED_EXAMPLE.md` -- one client followed from the line of text she
   arrives as, through the cleaning, into the product, and then through the
   entitlement model. Written by `make demo`, so the output is executed.
5. `docs/CLEANING_LEDGER.md` -- **what the cleaning actually did**: every
   transformation between the source file and the product, with its effect
   measured by a probe run against the database at build time, where the
   original value survives, and which rule watches it. `DECISIONS.md`
   D013-D020 is the reasoning behind each choice.
6. `docs/GOLD_LAYER.md` -- what is modelled today, what is cleaned and
   consumed by nothing, and the eight tables the cleaned data will carry with
   no new source file.
7. `docs/VISUAL_GUIDE.md` -- the figures: the pipeline, the query path, what
   each severity does, the star schema, two decision comparisons, the defect
   lifecycle and catalogue, the system map, the build sequence, the access
   model and the two-step login.
8. `semantic/semantic_layer.yaml` -- **the semantic solution**: the single
   source of business meaning. Entities with their grain, certified metric
   definitions, a glossary that says what each word is NOT, the data quality
   caveats with row counts, and the traps each question contains.
9. `semantic/context_pack.md` -- that file rendered into the exact text the LLM
   received. Nothing else was in its context.
10. `semantic/prompt_template.md` -- the prompt around it.
11. `src/sql_guard.py` -- what happens to the SQL the model produces before it
   is allowed to run. It decides whether a statement may run, not whether it
   answers the question: `docs/SEMANTIC_MODEL_AUDIT.md` measures that gap, and
   `scripts/ir_check_prototype.py` is a prototype, not wired into the app.
12. `sql/50_sec_rls.sql` and `sql/51_sec_auth.sql` -- the entitlement model,
   the row level security policies, the access grant set and the two-factor
   machinery (Task 3).
13. `dq/dq_rules.yaml` -- the 89 hand-written data quality rules, each
   with its severity and the reason for that severity (Task 1).
14. `llm_logs/` -- one JSON file per model call: prompt, model, parameters, raw
   response, timing and cost. This is the evidence behind the Questions tab
   (Claude Sonnet 5.5). `llm_logs/local/` holds a separate local-model run.
15. `dq/results/` -- the profile, the candidate defects, the data quality report,
   the reference answers, the LLM answers and the evaluation;
   `dq/results/local/` is the local model's run, scored the same way and never
   merged with the recorded one.

## Not part of the assessed pipeline

`packages/`, `.claude/agents/`, `tests/agentsim/`, `scripts/simulate_agents.py`
and `docs/MEDALLION_REFACTOR.md` are **next-step material**, included because
they show where this would go rather than what was built for the assessment.
They are a simulation of three layer-owning agents (bronze, silver, gold) over
an isolated-package split, run against a small control dataset. No production
code was refactored for them and no agent was triggered; `make all` does not
touch them. Run them with `make simulate`.

## Layout

```
docs/         the delivery audit, setup guides, access design, cleaning
              ledger, semantic audit, visual guide and diagrams
semantic/     the semantic layer, the rendered context pack, the prompt
sql/          numbered SQL, in execution order (00 schemas .. 70 defect injector)
src/          Python orchestration; src/config.py holds every shared constant
scripts/      windows.ps1 (native Windows targets), database and diagram helpers
tests/        the test suite, including the row level security bypass attempts
dq/           the rule set and every result it produced
llm_logs/     one audited record per LLM call
deliverables/ defects.csv, the model explanation and the DDR source text
```

## To run it

```
make up        # PostgreSQL 16 (docker compose, or a native cluster)
make all       # the whole pipeline (4m28s measured once on the Linux build)
make test      # the test suite
make simulate  # the next-step agent simulation (no database needed)
```

Native Windows, PostgreSQL installed locally (built and tested on 18):

```
scripts\windows.ps1 setup
scripts\windows.ps1 init-db
scripts\windows.ps1 build
scripts\windows.ps1 test
```

No credentials are included: connection settings come from the PG* variables
with the documented demo defaults, and an API key, if one is used, from the
environment only.
