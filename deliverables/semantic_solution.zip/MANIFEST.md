# semantic_solution.zip -- what is in here and where to start

This archive is the "semantic solution and any code/agents" deliverable for the
Berka take-home. It is a snapshot of the repository minus the raw data files
(17 MB of public PKDD'99 data; README.md says where to get them) and minus the
Excel workbook, which is a separate deliverable.

## Read in this order

1. `README.md` -- what was built, how to run it, and what the results were.
2. `semantic/semantic_layer.yaml` -- **the semantic solution**: the single
   source of business meaning. Entities with their grain, certified metric
   definitions, a glossary that says what each word is NOT, the data quality
   caveats with row counts, and the traps each question contains.
3. `semantic/context_pack.md` -- that file rendered into the exact text the LLM
   received. Nothing else was in its context.
4. `semantic/prompt_template.md` -- the prompt around it.
5. `src/sql_guard.py` -- what happens to the SQL the model produces before it
   is allowed to run.
6. `sql/50_sec_rls.sql` -- the entitlement model and the row level security
   policies (Task 3).
7. `dq/dq_rules.yaml` -- the 88 hand-written data quality rules, each with its
   severity and the reason for that severity (Task 1).
8. `llm_logs/` -- one JSON file per model call: prompt, model, parameters, raw
   response, timing and cost. This is the evidence behind the Questions tab.
9. `dq/results/` -- the profile, the candidate defects, the data quality report,
   the reference answers, the LLM answers and the evaluation.

## Layout

```
semantic/     the semantic layer, the rendered context pack, the prompt
sql/          numbered SQL, in execution order (00 schemas .. 70 defect injector)
src/          Python orchestration; src/config.py holds every shared constant
tests/        the test suite, including the row level security bypass attempts
dq/           the rule set and every result it produced
llm_logs/     one audited record per LLM call
deliverables/ defects.csv and the model explanation
```

## To run it

```
make up     # PostgreSQL 16 (docker compose, or a native cluster)
make all    # the whole pipeline, about 4.5 minutes
make test   # the test suite
```
